export interface Voo {
  horario: string;
  assentosEconomicos: number;
  assentosPrimeiraClasse: number;
  precoEconomico: number;
  precoPrimeiraClasse: number;
  classeSelecionada?: string;
  quantidadeSelecionada?: number;
}
